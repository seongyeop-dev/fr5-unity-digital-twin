PTP(ksy_pHome,30,30,0)
ActGripper(1,1)
WaitDI(0,1,0,2)
PTP(team_grip_origin,30,30,2,0,-150,-30,0,0,0)
PTP(team_grip_origin,5,30,2,0,0,-30,0,0,0)
PTP(team_grip_origin,5,30,0)
MoveGripper(1,72,30,30,2000,0,0,0,0,0)
PTP(team_grip_origin,30,30,2,0,-70,0,0,0,0)
PTP(team_fountain,10,30,0)
loop1 = 0 
while (loop1 < 3) do 

if WaitDI(1,1,0,2) then
PTP(team_fountain_1,10,30,2,0,0,-50,0,0,0)
PTP(team_fountain_1,10,30,0)
PTP(team_fountain_1,10,30,2,0,0,-50,0,0,0)
--elseif SPLCGetDI(2,1,10000) then
PTP(team_fountain_2,10,30,2,0,0,-50,0,0,0)
PTP(team_fountain_2,10,30,0)
PTP(team_fountain_2,10,30,2,0,0,-50,0,0,0)
--elseif SPLCGetDI(8,1,10000) then
PTP(team_fountain_3,10,30,2,0,0,-50,0,0,0)
PTP(team_fountain_3,10,30,0)
PTP(team_fountain_3,10,30,2,0,0,-50,0,0,0)
end
loop1 = loop1 + 1
end
PTP(team_fountain,10,30,0)
PTP(team_grip_origin,10,30,2,0,-150,-30,0,0,0)
PTP(team_grip_origin,10,30,2,0,-70,-30,0,0,0)
PTP(team_grip_origin,10,30,0)
MoveGripper(1,100,30,30,2000,0,0,0,0,0)
PTP(team_grip_origin,20,30,2,0,0,-30,0,0,0)
PTP(team_grip_origin,20,30,2,0,-150,-30,0,0,0)
PTP(team_glue_grip,30,30,2,0,0,-100,0,0,0)
PTP(team_glue_grip,10,30,0)
MoveGripper(1,72,30,30,2000,0,0,0,0,0)
PTP(team_glue_grip,10,30,2,0,0,-150,0,0,0)
PTP(team_glue_top,10,100,2,0,0,-100,0,0,0)
PTP(team_glue_top,10,100,2,0,0,-50,0,0,0)
PTP(team_glue_top,5,30,0)
MoveGripper(1,100,30,30,2000,0,0,0,0,0)
PTP(team_glue_top,10,100,2,0,0,-100,0,0,0)
PTP(team_grip_origin,30,30,2,0,-150,-30,0,0,0)
PTP(team_grip_origin,10,30,2,0,0,-30,0,0,0)
PTP(team_grip_origin,10,30,2,0,0,0,0,0,0)
MoveGripper(1,72,30,30,2000,0,0,0,0,0)
PTP(team_grip_origin,10,30,2,0,-150,0,0,0,0)
--PTP(team_shake_1_bottom,30,30,0)
--Spiral(team_shake_1_top,team_shake_1_origin,team_shake_1_bottom,50,0,0,0,0,0,0,0,5,0,0,0,1,1)
--PTP(team_spiral_bottom,30,30,0)
--Spiral(team_spiral_top,team_spiral_origin,team_spiral_bottom,50,0,0,0,0,0,0,0,5,0,0,0,10,10)
--PTP(team_shake_2_bottom,30,30,0)
--Spiral(team_shake_2_top,team_shake_2_origin,team_shake_2_bottom,50,0,0,0,0,0,0,0,5,0,0,0,1,1)
--PTP(team_grip_origin,30,30,2,0,-150,-30,0,0,0)
--PTP(team_grip_origin,30,30,2,0,-70,-30,0,0,0)
--PTP(team_grip_origin,10,30,2,0,0,0,0,0,0)
--MoveGripper(1,100,30,30,2000,0,0,0,0,0)
--PTP(team_grip_origin,10,30,2,0,0,-30,0,0,0)
--PTP(team_grip_origin,10,30,2,0,-150,-30,0,0,0)
--PTP(ksy_pHome,30,30,0)




