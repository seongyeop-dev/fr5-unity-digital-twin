PTP(team_grip_origin,30,0,0)
PTP(team_grip_origin,30,0,2,0,70,0,0,0,0)
