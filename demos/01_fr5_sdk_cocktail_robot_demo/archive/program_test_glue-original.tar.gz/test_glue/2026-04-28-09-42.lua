PTP(team_grip_origin,30,0,0)
PTP(team_grip_origin,30,0,2,0,70,0,0,0,0)
PTP(team_fountain,30,30,0)
PTP(team_fountain_1,30,30,0)
