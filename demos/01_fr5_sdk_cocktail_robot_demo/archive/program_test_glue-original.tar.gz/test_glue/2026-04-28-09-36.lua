PTP(team_grip_origin,30,0,2,0,0,30,0,0,0)
